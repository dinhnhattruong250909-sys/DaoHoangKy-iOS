import SwiftUI
import UIKit
import WebKit

/// The native container deliberately loads ONLY the bundled game files.
/// All 3D rendering and gameplay logic live in Web/game.js, not in Swift.
struct GameWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let content = WKUserContentController()

        // Inject the last native save before game.js executes. Useful if file://
        // localStorage is unavailable or WebKit's data store has been cleared.
        if let save = UserDefaults.standard.string(forKey: Coordinator.saveKey) {
            let quoted = Self.jsQuoted(save)
            let restore = "window.__DAOKY_NATIVE_SAVE = \(quoted);"
            content.addUserScript(WKUserScript(source: restore,
                                             injectionTime: .atDocumentStart,
                                             forMainFrameOnly: true))
        }
        content.add(context.coordinator, name: "nativeBridge")

        let config = WKWebViewConfiguration()
        config.userContentController = content
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.allowsInlineMediaPlayback = true

        let view = WKWebView(frame: .zero, configuration: config)
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        view.isOpaque = true
        view.backgroundColor = UIColor(red: 0.05, green: 0.12, blue: 0.17, alpha: 1)
        view.scrollView.isScrollEnabled = false
        view.scrollView.bounces = false
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.allowsBackForwardNavigationGestures = false

        GameRuntime.shared.webView = view

        if let entry = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            view.loadFileURL(entry, allowingReadAccessTo: entry.deletingLastPathComponent())
        } else {
            view.loadHTMLString("<h2 style='color:white;background:#122b38'>Missing Web/index.html in app bundle.</h2>", baseURL: nil)
        }
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) { }

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "nativeBridge")
        if GameRuntime.shared.webView === uiView { GameRuntime.shared.webView = nil }
        uiView.navigationDelegate = nil
        uiView.uiDelegate = nil
    }

    private static func jsQuoted(_ string: String) -> String {
        // A JSON-encoded string literal is safer than hand escaping a save.
        guard let data = try? JSONSerialization.data(withJSONObject: [string]),
              let array = String(data: data, encoding: .utf8) else { return "null" }
        return String(array.dropFirst().dropLast())
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
        static let saveKey = "DaoHoangKy.NativeSave.v1"

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "nativeBridge",
                  let body = message.body as? [String: Any],
                  let type = body["type"] as? String else { return }

            switch type {
            case "save":
                guard let save = body["json"] as? String, save.utf8.count <= 100_000,
                      let bytes = save.data(using: .utf8),
                      let data = try? JSONSerialization.jsonObject(with: bytes) as? [String: Any],
                      let stage = data["stage"] as? Int, (1...4).contains(stage) else { return }
                UserDefaults.standard.set(save, forKey: Self.saveKey)

            case "haptic":
                let kind = body["kind"] as? String ?? "light"
                if kind == "success" {
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                } else {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                }

            default: break
            }
        }

        // The game is fully offline. Reject outbound in-webview navigation.
        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            decisionHandler((url.isFileURL || url.scheme == "about") ? .allow : .cancel)
        }

        // The web version asks for confirmation when the player resets progress.
        func webView(_ webView: WKWebView,
                     runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping (Bool) -> Void) {
            guard let root = webView.window?.rootViewController else {
                completionHandler(false)
                return
            }
            var presenter = root
            while let presented = presenter.presentedViewController { presenter = presented }
            let alert = UIAlertController(title: "Đảo Hoang Ký", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hủy", style: .cancel, handler: { _ in completionHandler(false) }))
            alert.addAction(UIAlertAction(title: "Đồng ý", style: .destructive, handler: { _ in completionHandler(true) }))
            presenter.present(alert, animated: true)
        }
    }
}

final class GameRuntime {
    static let shared = GameRuntime()
    weak var webView: WKWebView?
    private init() { }

    func saveNow() {
        webView?.evaluateJavaScript("if (typeof save === 'function' && state.started) save();", completionHandler: nil)
    }
}
