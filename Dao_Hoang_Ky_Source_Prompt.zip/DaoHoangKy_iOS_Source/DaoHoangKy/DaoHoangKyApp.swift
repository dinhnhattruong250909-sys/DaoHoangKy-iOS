import SwiftUI

@main
struct DaoHoangKyApp: App {
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            GameWebView()
                .ignoresSafeArea()
                .statusBarHidden(true)
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase != .active {
                GameRuntime.shared.saveNow()
            }
        }
    }
}
