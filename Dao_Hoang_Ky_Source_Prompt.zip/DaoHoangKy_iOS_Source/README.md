# ĐẢO HOANG KÝ — MÃ NGUỒN ỨNG DỤNG iOS (v1.0.0)

Đây là **mã nguồn iOS có thể mở trong Xcode** cho bản game sinh tồn 3D trước đó.
Game được viết bằng **WebGL thuần (HTML/CSS/JavaScript)**, chạy ngoại tuyến bên trong
một ứng dụng iOS **SwiftUI + WKWebView**. KHÔNG phải game native Unity/Unreal,
và đây là bản prototype, KHÔNG phải game thương mại hoàn thiện.

## Cấu trúc

- `DaoHoangKy.xcodeproj`: dự án Xcode, gồm iOS app target.
- `DaoHoangKy/DaoHoangKyApp.swift`: điểm vào ứng dụng SwiftUI.
- `DaoHoangKy/GameWebView.swift`: tích hợp WebKit, lưu tiến độ native, phản hồi rung,
  xác nhận đặt lại game; chỉ cho phép tải nội dung local.
- `DaoHoangKy/Web/index.html`: UI và màn hình game.
- `DaoHoangKy/Web/styles.css`: bố cục, nút cảm ứng, safe area iPhone.
- `DaoHoangKy/Web/game.js`: gameplay, môi trường WebGL 3D, 4 chương, vật phẩm,
  xây dựng, chiến đấu, thuyền buồm, lưu game.
- `DaoHoangKy/Assets.xcassets`: biểu tượng ứng dụng 1024×1024.
- `DaoHoangKy/Info.plist`: cấu hình iOS, chỉ cho xoay màn hình ngang.
- `DaoHoangKy/PrivacyInfo.xcprivacy`: không theo dõi / không thu thập dữ liệu.

## Cách chạy trên máy Mac

1. Giải nén ZIP, mở `DaoHoangKy.xcodeproj` bằng Xcode (khuyến nghị bản Xcode mới).
2. Chọn project `DaoHoangKy` → target `DaoHoangKy` → `Signing & Capabilities`.
3. Chọn **Team** Apple Developer của bạn. Thay `Bundle Identifier`
   `com.example.DaoHoangKy` bằng ID duy nhất, ví dụ `vn.tenban.daohongky`.
4. Kết nối iPhone hoặc chọn simulator iPhone hỗ trợ WebGL. Chọn device → `Run` (▶).
5. Xoay ngang iPhone. Chọn 'Bắt đầu phiêu lưu'.

## Xuất IPA qua Xcode

1. Trên Mac, chọn `Any iOS Device (arm64)` hoặc thiết bị iOS phù hợp.
2. Chọn `Product → Archive`.
3. Trong Organizer → chọn Archive → `Distribute App` → hình thức phân phối
   phù hợp tài khoản: Development / Ad Hoc / App Store Connect.
4. Làm theo hướng dẫn signing và export. Với Development/Ad Hoc, Xcode có thể
   xuất `.ipa` cho các thiết bị được phép. Cách cài tùy chứng chỉ/provisioning.

**Quan trọng:** Chỉ máy Mac có Xcode, iOS SDK và cấu hình ký mã mới xuất IPA
đúng cách. Chưa thể compile Swift iOS hay xuất IPA tại môi trường làm việc này.

## Tính năng hiện tại

- Lv.1 — Thu thập gỗ, đá, dừa, xơ dừa; HUD sinh tồn, tạo vật phẩm.
- Lv.8 — Dựng tường gỗ, lửa trại, bàn chế tạo; chó đồng hành.
- Lv.15 — Đánh lợn rừng, theo dõi HP, stamina, chế tạo thức ăn.
- Lv.25 — Lái thuyền buồm, đến núi lửa và hoàn thành hành trình.
- Giao diện tiếng Việt, cảm ứng iPhone và bàn phím trên Mac.
- Lưu tiến độ: localStorage (trình duyệt) + UserDefaults (ứng dụng iOS).
- Không dùng CDN, không cần Internet khi chơi, không phụ thuộc SDK ngoài.

## Sửa mã nguồn

- Thay gameplay trong `Web/game.js`.
- Thay giao diện trong `Web/styles.css` / `Web/index.html`.
- Thay tên game: `Info.plist` (`CFBundleDisplayName`) và SwiftUI.
- Thay biểu tượng: `Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png`.

## Giới hạn hiện tại

- Mô hình 3D có phong cách low-poly, không có animation/asset chất lượng AAA.
- Xây dựng theo các công thức cố định, chưa có blueprint 3D kéo-thả chuẩn.
- Lưu tiến độ gồm chương, tài nguyên, công trình, HP; chưa lưu toàn bộ tọa độ.
- Chưa tích hợp Game Center, thanh toán, quảng cáo hay đa người chơi.
- Bản gốc WebGL có thiết kế prototype, có thể cần tối ưu thêm trên iPhone cũ.
- Apple có tiêu chí xét duyệt riêng; build thành IPA không bảo đảm App Store phê duyệt.

## Kiểm thử nguồn

`node --check DaoHoangKy/Web/game.js`
`python3 -m http.server` (trong thư mục Web) → mở `http://localhost:8000`

Nguồn 3D không sử dụng tài nguyên mạng; tệp preview không bắt buộc trong build.
