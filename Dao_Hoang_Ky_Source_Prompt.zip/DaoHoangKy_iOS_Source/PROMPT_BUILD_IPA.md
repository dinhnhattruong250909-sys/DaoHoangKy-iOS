# Prompt build IPA Đảo Hoang Ký

Bạn là kỹ sư build iOS. Tôi cung cấp dự án Xcode Đảo Hoang Ký trong cùng ZIP với prompt này. Hãy thực hiện build trên macOS có Xcode và iOS SDK.

1. Kiểm tra phiên bản Xcode, cấu trúc dự án, scheme DaoHoangKy và tài nguyên Web. Giữ nguyên gameplay và mã nguồn.
2. Build target DaoHoangKy cho iPhone arm64 ở cấu hình Release. Ghi đầy đủ log và tự sửa các lỗi build thông thường nếu có. Không dùng file giả hoặc đổi tên ZIP thành IPA.
3. Xuất một IPA chưa ký nếu tôi sẽ ký bằng ESign. Đặt Bundle ID theo giá trị tôi cung cấp. Nếu tôi chưa cung cấp, dùng com.example.DaoHoangKy và ghi rõ để tôi chọn provisioning profile phù hợp. Không yêu cầu hoặc lưu khóa riêng, file .p12 hay mật khẩu vào repository.
4. Kiểm tra IPA bằng cách giải nén, xác nhận Payload/DaoHoangKy.app chứa executable arm64, Web/index.html, Web/game.js và Web/styles.css. Tính SHA-256.
5. Bàn giao IPA, log build, checksum và báo cáo ngắn về Xcode, Bundle ID, trạng thái ký và các giới hạn kiểm thử. Nếu build thất bại, bàn giao log và nguyên nhân cụ thể, không báo thành công.
6. Nếu dùng GitHub Actions, dùng macOS runner và workflow build-ios.yml đi kèm. Tải artifact IPA về sau khi workflow hoàn tất. Không đưa chứng chỉ ký lên GitHub.
