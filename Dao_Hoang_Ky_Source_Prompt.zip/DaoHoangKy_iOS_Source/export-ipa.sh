#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob

if [[ "$(uname -s)" != Darwin ]] || ! command -v xcodebuild >/dev/null; then
    echo 'Cần macOS và Xcode để tạo IPA.' >&2
    exit 1
fi
xcrun --sdk iphoneos --show-sdk-path >/dev/null

if [[ $# -ne 2 || ! "$1" =~ ^[A-Z0-9]{10}$ || ! "$2" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]]; then
    printf 'Cách dùng: %s TEAM_ID BUNDLE_ID\n' "$0" >&2
    exit 2
fi

team_id=$1
bundle_id=$2
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
output_parent="$project_dir/build"
mkdir -p "$output_parent"
output_dir="$(mktemp -d "$output_parent/DaoHoangKy.XXXXXX")"
archive="$output_dir/DaoHoangKy.xcarchive"
export_options="$output_dir/ExportOptions.plist"

provisioning_args=()
if [[ "${ALLOW_PROVISIONING_UPDATES:-0}" == 1 ]]; then
    provisioning_args=(-allowProvisioningUpdates)
fi

printf 'Kết quả và log: %s\n' "$output_dir"
xcodebuild archive \
    -project "$project_dir/DaoHoangKy.xcodeproj" \
    -scheme DaoHoangKy \
    -configuration Release \
    -destination 'generic/platform=iOS' \
    -archivePath "$archive" \
    ${provisioning_args[@]+"${provisioning_args[@]}"} \
    DEVELOPMENT_TEAM="$team_id" \
    PRODUCT_BUNDLE_IDENTIFIER="$bundle_id" \
    2>&1 | tee "$output_dir/archive.log"

plutil -create xml1 "$export_options"
plutil -insert method -string debugging "$export_options"
plutil -insert signingStyle -string automatic "$export_options"
plutil -insert teamID -string "$team_id" "$export_options"

xcodebuild -exportArchive \
    -archivePath "$archive" \
    -exportPath "$output_dir/ipa" \
    -exportOptionsPlist "$export_options" \
    ${provisioning_args[@]+"${provisioning_args[@]}"} \
    2>&1 | tee "$output_dir/export.log"

ipa_files=("$output_dir"/ipa/*.ipa)
if [[ ${#ipa_files[@]} -ne 1 ]]; then
    echo 'Xcode phải xuất đúng một file IPA.' >&2
    exit 1
fi
ipa="${ipa_files[0]}"
unzip -tq "$ipa"
verification_dir="$(mktemp -d "$output_dir/verify.XXXXXX")"
trap 'rm -rf -- "$verification_dir"' EXIT
ditto -x -k "$ipa" "$verification_dir"
app="$verification_dir/Payload/DaoHoangKy.app"
test -x "$app/DaoHoangKy"
test -f "$app/Web/index.html"
test -f "$app/Web/game.js"
test -f "$app/Web/styles.css"
codesign --verify --strict "$app"
shasum -a 256 "$ipa" | tee "$output_dir/SHA256SUMS.txt"
printf 'IPA: %s\n' "$ipa"
